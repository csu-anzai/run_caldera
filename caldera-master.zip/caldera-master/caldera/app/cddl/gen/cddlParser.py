# Generated from C:/Users/dpmiller/projects/caldera/caldera/app/cddl\cddl.g4 by ANTLR 4.7
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3&")
        buf.write("\u00ea\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23\t\23")
        buf.write("\4\24\t\24\4\25\t\25\3\2\6\2,\n\2\r\2\16\2-\3\2\3\2\3")
        buf.write("\3\5\3\63\n\3\3\3\5\3\66\n\3\3\3\3\3\5\3:\n\3\3\3\3\3")
        buf.write("\3\4\3\4\3\4\3\5\3\5\3\5\3\6\3\6\7\6F\n\6\f\6\16\6I\13")
        buf.write("\6\3\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\b\3\b\7\bU\n\b\f")
        buf.write("\b\16\bX\13\b\3\b\3\b\5\b\\\n\b\3\t\3\t\7\t`\n\t\f\t\16")
        buf.write("\tc\13\t\3\n\3\n\3\n\3\n\3\13\3\13\7\13k\n\13\f\13\16")
        buf.write("\13n\13\13\3\f\6\fq\n\f\r\f\16\fr\3\r\3\r\3\r\3\r\3\r")
        buf.write("\3\r\3\r\3\r\3\r\3\r\3\r\7\r\u0080\n\r\f\r\16\r\u0083")
        buf.write("\13\r\3\r\3\r\3\r\3\r\3\r\5\r\u008a\n\r\3\r\3\r\3\r\3")
        buf.write("\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\5\r\u009b")
        buf.write("\n\r\3\16\3\16\3\16\3\16\3\16\3\16\7\16\u00a3\n\16\f\16")
        buf.write("\16\16\u00a6\13\16\3\16\3\16\5\16\u00aa\n\16\3\17\3\17")
        buf.write("\3\17\3\17\3\17\7\17\u00b1\n\17\f\17\16\17\u00b4\13\17")
        buf.write("\3\17\3\17\3\20\3\20\3\20\3\20\5\20\u00bc\n\20\3\21\3")
        buf.write("\21\3\21\7\21\u00c1\n\21\f\21\16\21\u00c4\13\21\3\22\3")
        buf.write("\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22")
        buf.write("\5\22\u00d2\n\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3")
        buf.write("\22\7\22\u00dc\n\22\f\22\16\22\u00df\13\22\3\23\3\23\3")
        buf.write("\24\3\24\3\24\5\24\u00e6\n\24\3\25\3\25\3\25\2\3\"\26")
        buf.write("\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(\2\4\3\2")
        buf.write("\35\36\3\2!\"\2\u00f4\2+\3\2\2\2\4\62\3\2\2\2\6=\3\2\2")
        buf.write("\2\b@\3\2\2\2\nC\3\2\2\2\fJ\3\2\2\2\16[\3\2\2\2\20]\3")
        buf.write("\2\2\2\22d\3\2\2\2\24h\3\2\2\2\26p\3\2\2\2\30\u009a\3")
        buf.write("\2\2\2\32\u00a9\3\2\2\2\34\u00ab\3\2\2\2\36\u00bb\3\2")
        buf.write("\2\2 \u00bd\3\2\2\2\"\u00d1\3\2\2\2$\u00e0\3\2\2\2&\u00e5")
        buf.write("\3\2\2\2(\u00e7\3\2\2\2*,\5\4\3\2+*\3\2\2\2,-\3\2\2\2")
        buf.write("-+\3\2\2\2-.\3\2\2\2./\3\2\2\2/\60\7\2\2\3\60\3\3\2\2")
        buf.write("\2\61\63\5\6\4\2\62\61\3\2\2\2\62\63\3\2\2\2\63\65\3\2")
        buf.write("\2\2\64\66\5\b\5\2\65\64\3\2\2\2\65\66\3\2\2\2\66\67\3")
        buf.write("\2\2\2\679\5\n\6\28:\5\20\t\298\3\2\2\29:\3\2\2\2:;\3")
        buf.write("\2\2\2;<\5\24\13\2<\5\3\2\2\2=>\7\3\2\2>?\7$\2\2?\7\3")
        buf.write("\2\2\2@A\7\4\2\2AB\7#\2\2B\t\3\2\2\2CG\7\5\2\2DF\5\f\7")
        buf.write("\2ED\3\2\2\2FI\3\2\2\2GE\3\2\2\2GH\3\2\2\2H\13\3\2\2\2")
        buf.write("IG\3\2\2\2JK\7$\2\2KL\7\6\2\2LM\5\16\b\2M\r\3\2\2\2N\\")
        buf.write("\7$\2\2OP\7$\2\2PQ\7\7\2\2QV\5\16\b\2RS\7\b\2\2SU\5\16")
        buf.write("\b\2TR\3\2\2\2UX\3\2\2\2VT\3\2\2\2VW\3\2\2\2WY\3\2\2\2")
        buf.write("XV\3\2\2\2YZ\7\t\2\2Z\\\3\2\2\2[N\3\2\2\2[O\3\2\2\2\\")
        buf.write("\17\3\2\2\2]a\7\n\2\2^`\5\22\n\2_^\3\2\2\2`c\3\2\2\2a")
        buf.write("_\3\2\2\2ab\3\2\2\2b\21\3\2\2\2ca\3\2\2\2de\5 \21\2ef")
        buf.write("\5&\24\2fg\5 \21\2g\23\3\2\2\2hl\7\13\2\2ik\5\26\f\2j")
        buf.write("i\3\2\2\2kn\3\2\2\2lj\3\2\2\2lm\3\2\2\2m\25\3\2\2\2nl")
        buf.write("\3\2\2\2oq\5\30\r\2po\3\2\2\2qr\3\2\2\2rp\3\2\2\2rs\3")
        buf.write("\2\2\2s\27\3\2\2\2tu\7\f\2\2uv\5\"\22\2vw\7\r\2\2wx\5")
        buf.write("\26\f\2x\u0081\7\16\2\2yz\7\17\2\2z{\5\"\22\2{|\7\r\2")
        buf.write("\2|}\5\26\f\2}~\7\16\2\2~\u0080\3\2\2\2\177y\3\2\2\2\u0080")
        buf.write("\u0083\3\2\2\2\u0081\177\3\2\2\2\u0081\u0082\3\2\2\2\u0082")
        buf.write("\u0089\3\2\2\2\u0083\u0081\3\2\2\2\u0084\u0085\7\20\2")
        buf.write("\2\u0085\u0086\7\r\2\2\u0086\u0087\5\26\f\2\u0087\u0088")
        buf.write("\7\16\2\2\u0088\u008a\3\2\2\2\u0089\u0084\3\2\2\2\u0089")
        buf.write("\u008a\3\2\2\2\u008a\u009b\3\2\2\2\u008b\u008c\7\21\2")
        buf.write("\2\u008c\u009b\5\34\17\2\u008d\u008e\7\22\2\2\u008e\u009b")
        buf.write("\5\32\16\2\u008f\u0090\7\23\2\2\u0090\u009b\5\32\16\2")
        buf.write("\u0091\u0092\7\24\2\2\u0092\u0093\7$\2\2\u0093\u0094\7")
        buf.write("\25\2\2\u0094\u0095\5 \21\2\u0095\u0096\7\r\2\2\u0096")
        buf.write("\u0097\5\26\f\2\u0097\u0098\7\16\2\2\u0098\u009b\3\2\2")
        buf.write("\2\u0099\u009b\7\26\2\2\u009at\3\2\2\2\u009a\u008b\3\2")
        buf.write("\2\2\u009a\u008d\3\2\2\2\u009a\u008f\3\2\2\2\u009a\u0091")
        buf.write("\3\2\2\2\u009a\u0099\3\2\2\2\u009b\31\3\2\2\2\u009c\u00aa")
        buf.write("\5 \21\2\u009d\u009e\5 \21\2\u009e\u009f\7\7\2\2\u009f")
        buf.write("\u00a4\5\32\16\2\u00a0\u00a1\7\b\2\2\u00a1\u00a3\5\32")
        buf.write("\16\2\u00a2\u00a0\3\2\2\2\u00a3\u00a6\3\2\2\2\u00a4\u00a2")
        buf.write("\3\2\2\2\u00a4\u00a5\3\2\2\2\u00a5\u00a7\3\2\2\2\u00a6")
        buf.write("\u00a4\3\2\2\2\u00a7\u00a8\7\t\2\2\u00a8\u00aa\3\2\2\2")
        buf.write("\u00a9\u009c\3\2\2\2\u00a9\u009d\3\2\2\2\u00aa\33\3\2")
        buf.write("\2\2\u00ab\u00ac\7$\2\2\u00ac\u00ad\7\7\2\2\u00ad\u00b2")
        buf.write("\5\36\20\2\u00ae\u00af\7\b\2\2\u00af\u00b1\5\36\20\2\u00b0")
        buf.write("\u00ae\3\2\2\2\u00b1\u00b4\3\2\2\2\u00b2\u00b0\3\2\2\2")
        buf.write("\u00b2\u00b3\3\2\2\2\u00b3\u00b5\3\2\2\2\u00b4\u00b2\3")
        buf.write("\2\2\2\u00b5\u00b6\7\t\2\2\u00b6\35\3\2\2\2\u00b7\u00bc")
        buf.write("\7$\2\2\u00b8\u00b9\7$\2\2\u00b9\u00ba\7\27\2\2\u00ba")
        buf.write("\u00bc\5\"\22\2\u00bb\u00b7\3\2\2\2\u00bb\u00b8\3\2\2")
        buf.write("\2\u00bc\37\3\2\2\2\u00bd\u00c2\7$\2\2\u00be\u00bf\7\30")
        buf.write("\2\2\u00bf\u00c1\7$\2\2\u00c0\u00be\3\2\2\2\u00c1\u00c4")
        buf.write("\3\2\2\2\u00c2\u00c0\3\2\2\2\u00c2\u00c3\3\2\2\2\u00c3")
        buf.write("!\3\2\2\2\u00c4\u00c2\3\2\2\2\u00c5\u00c6\b\22\1\2\u00c6")
        buf.write("\u00c7\7\31\2\2\u00c7\u00c8\5\"\22\2\u00c8\u00c9\7\32")
        buf.write("\2\2\u00c9\u00d2\3\2\2\2\u00ca\u00cb\7\33\2\2\u00cb\u00d2")
        buf.write("\5\"\22\t\u00cc\u00cd\7\34\2\2\u00cd\u00d2\5\"\22\b\u00ce")
        buf.write("\u00d2\5$\23\2\u00cf\u00d2\5 \21\2\u00d0\u00d2\7#\2\2")
        buf.write("\u00d1\u00c5\3\2\2\2\u00d1\u00ca\3\2\2\2\u00d1\u00cc\3")
        buf.write("\2\2\2\u00d1\u00ce\3\2\2\2\u00d1\u00cf\3\2\2\2\u00d1\u00d0")
        buf.write("\3\2\2\2\u00d2\u00dd\3\2\2\2\u00d3\u00d4\f\7\2\2\u00d4")
        buf.write("\u00d5\5&\24\2\u00d5\u00d6\5\"\22\b\u00d6\u00dc\3\2\2")
        buf.write("\2\u00d7\u00d8\f\6\2\2\u00d8\u00d9\5(\25\2\u00d9\u00da")
        buf.write("\5\"\22\7\u00da\u00dc\3\2\2\2\u00db\u00d3\3\2\2\2\u00db")
        buf.write("\u00d7\3\2\2\2\u00dc\u00df\3\2\2\2\u00dd\u00db\3\2\2\2")
        buf.write("\u00dd\u00de\3\2\2\2\u00de#\3\2\2\2\u00df\u00dd\3\2\2")
        buf.write("\2\u00e0\u00e1\t\2\2\2\u00e1%\3\2\2\2\u00e2\u00e6\7\37")
        buf.write("\2\2\u00e3\u00e6\7\25\2\2\u00e4\u00e6\7 \2\2\u00e5\u00e2")
        buf.write("\3\2\2\2\u00e5\u00e3\3\2\2\2\u00e5\u00e4\3\2\2\2\u00e6")
        buf.write("\'\3\2\2\2\u00e7\u00e8\t\3\2\2\u00e8)\3\2\2\2\30-\62\65")
        buf.write("9GV[alr\u0081\u0089\u009a\u00a4\u00a9\u00b2\u00bb\u00c2")
        buf.write("\u00d1\u00db\u00dd\u00e5")
        return buf.getvalue()


class cddlParser ( Parser ):

    grammarFileName = "cddl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'Name:'", "'Description:'", "'Knowns:'", 
                     "':'", "'['", "','", "']'", "'Where:'", "'Effects:'", 
                     "'if'", "'{'", "'}'", "'elif'", "'else'", "'create'", 
                     "'know'", "'forget'", "'for'", "'in'", "'pass'", "'='", 
                     "'.'", "'('", "')'", "'not'", "'exist'", "'True'", 
                     "'False'", "'!='", "'=='", "'and'", "'or'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "STRING", "ID", "COMMENT", "WS" ]

    RULE_actions = 0
    RULE_action = 1
    RULE_name = 2
    RULE_description = 3
    RULE_knowns = 4
    RULE_known = 5
    RULE_known_assign = 6
    RULE_wheres = 7
    RULE_where_expr = 8
    RULE_effects = 9
    RULE_stmts = 10
    RULE_stmt = 11
    RULE_knows_object = 12
    RULE_obj_create = 13
    RULE_eq_list = 14
    RULE_obj = 15
    RULE_expr = 16
    RULE_bool_val = 17
    RULE_comp = 18
    RULE_bin_comp = 19

    ruleNames =  [ "actions", "action", "name", "description", "knowns", 
                   "known", "known_assign", "wheres", "where_expr", "effects", 
                   "stmts", "stmt", "knows_object", "obj_create", "eq_list", 
                   "obj", "expr", "bool_val", "comp", "bin_comp" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    T__24=25
    T__25=26
    T__26=27
    T__27=28
    T__28=29
    T__29=30
    T__30=31
    T__31=32
    STRING=33
    ID=34
    COMMENT=35
    WS=36

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ActionsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(cddlParser.EOF, 0)

        def action(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.ActionContext)
            else:
                return self.getTypedRuleContext(cddlParser.ActionContext,i)


        def getRuleIndex(self):
            return cddlParser.RULE_actions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterActions" ):
                listener.enterActions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitActions" ):
                listener.exitActions(self)




    def actions(self):

        localctx = cddlParser.ActionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_actions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 41 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 40
                self.action()
                self.state = 43 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << cddlParser.T__0) | (1 << cddlParser.T__1) | (1 << cddlParser.T__2))) != 0)):
                    break

            self.state = 45
            self.match(cddlParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ActionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def knowns(self):
            return self.getTypedRuleContext(cddlParser.KnownsContext,0)


        def effects(self):
            return self.getTypedRuleContext(cddlParser.EffectsContext,0)


        def name(self):
            return self.getTypedRuleContext(cddlParser.NameContext,0)


        def description(self):
            return self.getTypedRuleContext(cddlParser.DescriptionContext,0)


        def wheres(self):
            return self.getTypedRuleContext(cddlParser.WheresContext,0)


        def getRuleIndex(self):
            return cddlParser.RULE_action

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAction" ):
                listener.enterAction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAction" ):
                listener.exitAction(self)




    def action(self):

        localctx = cddlParser.ActionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_action)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 48
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==cddlParser.T__0:
                self.state = 47
                self.name()


            self.state = 51
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==cddlParser.T__1:
                self.state = 50
                self.description()


            self.state = 53
            self.knowns()
            self.state = 55
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==cddlParser.T__7:
                self.state = 54
                self.wheres()


            self.state = 57
            self.effects()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class NameContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(cddlParser.ID, 0)

        def getRuleIndex(self):
            return cddlParser.RULE_name

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterName" ):
                listener.enterName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitName" ):
                listener.exitName(self)




    def name(self):

        localctx = cddlParser.NameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 59
            self.match(cddlParser.T__0)
            self.state = 60
            self.match(cddlParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class DescriptionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(cddlParser.STRING, 0)

        def getRuleIndex(self):
            return cddlParser.RULE_description

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDescription" ):
                listener.enterDescription(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDescription" ):
                listener.exitDescription(self)




    def description(self):

        localctx = cddlParser.DescriptionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_description)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 62
            self.match(cddlParser.T__1)
            self.state = 63
            self.match(cddlParser.STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class KnownsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def known(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.KnownContext)
            else:
                return self.getTypedRuleContext(cddlParser.KnownContext,i)


        def getRuleIndex(self):
            return cddlParser.RULE_knowns

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKnowns" ):
                listener.enterKnowns(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKnowns" ):
                listener.exitKnowns(self)




    def knowns(self):

        localctx = cddlParser.KnownsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_knowns)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 65
            self.match(cddlParser.T__2)
            self.state = 69
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==cddlParser.ID:
                self.state = 66
                self.known()
                self.state = 71
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class KnownContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(cddlParser.ID, 0)

        def known_assign(self):
            return self.getTypedRuleContext(cddlParser.Known_assignContext,0)


        def getRuleIndex(self):
            return cddlParser.RULE_known

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKnown" ):
                listener.enterKnown(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKnown" ):
                listener.exitKnown(self)




    def known(self):

        localctx = cddlParser.KnownContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_known)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 72
            self.match(cddlParser.ID)
            self.state = 73
            self.match(cddlParser.T__3)
            self.state = 74
            self.known_assign()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Known_assignContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(cddlParser.ID, 0)

        def known_assign(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.Known_assignContext)
            else:
                return self.getTypedRuleContext(cddlParser.Known_assignContext,i)


        def getRuleIndex(self):
            return cddlParser.RULE_known_assign

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKnown_assign" ):
                listener.enterKnown_assign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKnown_assign" ):
                listener.exitKnown_assign(self)




    def known_assign(self):

        localctx = cddlParser.Known_assignContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_known_assign)
        self._la = 0 # Token type
        try:
            self.state = 89
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 76
                self.match(cddlParser.ID)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 77
                self.match(cddlParser.ID)
                self.state = 78
                self.match(cddlParser.T__4)
                self.state = 79
                self.known_assign()
                self.state = 84
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==cddlParser.T__5:
                    self.state = 80
                    self.match(cddlParser.T__5)
                    self.state = 81
                    self.known_assign()
                    self.state = 86
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 87
                self.match(cddlParser.T__6)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class WheresContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def where_expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.Where_exprContext)
            else:
                return self.getTypedRuleContext(cddlParser.Where_exprContext,i)


        def getRuleIndex(self):
            return cddlParser.RULE_wheres

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWheres" ):
                listener.enterWheres(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWheres" ):
                listener.exitWheres(self)




    def wheres(self):

        localctx = cddlParser.WheresContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_wheres)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 91
            self.match(cddlParser.T__7)
            self.state = 95
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==cddlParser.ID:
                self.state = 92
                self.where_expr()
                self.state = 97
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Where_exprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def obj(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.ObjContext)
            else:
                return self.getTypedRuleContext(cddlParser.ObjContext,i)


        def comp(self):
            return self.getTypedRuleContext(cddlParser.CompContext,0)


        def getRuleIndex(self):
            return cddlParser.RULE_where_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhere_expr" ):
                listener.enterWhere_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhere_expr" ):
                listener.exitWhere_expr(self)




    def where_expr(self):

        localctx = cddlParser.Where_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_where_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 98
            self.obj()
            self.state = 99
            self.comp()
            self.state = 100
            self.obj()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class EffectsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmts(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.StmtsContext)
            else:
                return self.getTypedRuleContext(cddlParser.StmtsContext,i)


        def getRuleIndex(self):
            return cddlParser.RULE_effects

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEffects" ):
                listener.enterEffects(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEffects" ):
                listener.exitEffects(self)




    def effects(self):

        localctx = cddlParser.EffectsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_effects)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 102
            self.match(cddlParser.T__8)
            self.state = 106
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << cddlParser.T__9) | (1 << cddlParser.T__14) | (1 << cddlParser.T__15) | (1 << cddlParser.T__16) | (1 << cddlParser.T__17) | (1 << cddlParser.T__19))) != 0):
                self.state = 103
                self.stmts()
                self.state = 108
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StmtsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.StmtContext)
            else:
                return self.getTypedRuleContext(cddlParser.StmtContext,i)


        def getRuleIndex(self):
            return cddlParser.RULE_stmts

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmts" ):
                listener.enterStmts(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmts" ):
                listener.exitStmts(self)




    def stmts(self):

        localctx = cddlParser.StmtsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_stmts)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 110 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 109
                    self.stmt()

                else:
                    raise NoViableAltException(self)
                self.state = 112 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return cddlParser.RULE_stmt

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class PassContext(StmtContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.StmtContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPass" ):
                listener.enterPass(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPass" ):
                listener.exitPass(self)


    class CreateContext(StmtContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.StmtContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def obj_create(self):
            return self.getTypedRuleContext(cddlParser.Obj_createContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCreate" ):
                listener.enterCreate(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCreate" ):
                listener.exitCreate(self)


    class ForContext(StmtContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.StmtContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(cddlParser.ID, 0)
        def obj(self):
            return self.getTypedRuleContext(cddlParser.ObjContext,0)

        def stmts(self):
            return self.getTypedRuleContext(cddlParser.StmtsContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFor" ):
                listener.enterFor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFor" ):
                listener.exitFor(self)


    class ForgetContext(StmtContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.StmtContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def knows_object(self):
            return self.getTypedRuleContext(cddlParser.Knows_objectContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterForget" ):
                listener.enterForget(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitForget" ):
                listener.exitForget(self)


    class KnowsContext(StmtContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.StmtContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def knows_object(self):
            return self.getTypedRuleContext(cddlParser.Knows_objectContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKnows" ):
                listener.enterKnows(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKnows" ):
                listener.exitKnows(self)


    class IfContext(StmtContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.StmtContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.ExprContext)
            else:
                return self.getTypedRuleContext(cddlParser.ExprContext,i)

        def stmts(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.StmtsContext)
            else:
                return self.getTypedRuleContext(cddlParser.StmtsContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIf" ):
                listener.enterIf(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIf" ):
                listener.exitIf(self)



    def stmt(self):

        localctx = cddlParser.StmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_stmt)
        self._la = 0 # Token type
        try:
            self.state = 152
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [cddlParser.T__9]:
                localctx = cddlParser.IfContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 114
                self.match(cddlParser.T__9)
                self.state = 115
                self.expr(0)
                self.state = 116
                self.match(cddlParser.T__10)
                self.state = 117
                self.stmts()
                self.state = 118
                self.match(cddlParser.T__11)
                self.state = 127
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==cddlParser.T__12:
                    self.state = 119
                    self.match(cddlParser.T__12)
                    self.state = 120
                    self.expr(0)
                    self.state = 121
                    self.match(cddlParser.T__10)
                    self.state = 122
                    self.stmts()
                    self.state = 123
                    self.match(cddlParser.T__11)
                    self.state = 129
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 135
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==cddlParser.T__13:
                    self.state = 130
                    self.match(cddlParser.T__13)
                    self.state = 131
                    self.match(cddlParser.T__10)
                    self.state = 132
                    self.stmts()
                    self.state = 133
                    self.match(cddlParser.T__11)


                pass
            elif token in [cddlParser.T__14]:
                localctx = cddlParser.CreateContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 137
                self.match(cddlParser.T__14)
                self.state = 138
                self.obj_create()
                pass
            elif token in [cddlParser.T__15]:
                localctx = cddlParser.KnowsContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 139
                self.match(cddlParser.T__15)
                self.state = 140
                self.knows_object()
                pass
            elif token in [cddlParser.T__16]:
                localctx = cddlParser.ForgetContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 141
                self.match(cddlParser.T__16)
                self.state = 142
                self.knows_object()
                pass
            elif token in [cddlParser.T__17]:
                localctx = cddlParser.ForContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 143
                self.match(cddlParser.T__17)
                self.state = 144
                self.match(cddlParser.ID)
                self.state = 145
                self.match(cddlParser.T__18)
                self.state = 146
                self.obj()
                self.state = 147
                self.match(cddlParser.T__10)
                self.state = 148
                self.stmts()
                self.state = 149
                self.match(cddlParser.T__11)
                pass
            elif token in [cddlParser.T__19]:
                localctx = cddlParser.PassContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 151
                self.match(cddlParser.T__19)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Knows_objectContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def obj(self):
            return self.getTypedRuleContext(cddlParser.ObjContext,0)


        def knows_object(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.Knows_objectContext)
            else:
                return self.getTypedRuleContext(cddlParser.Knows_objectContext,i)


        def getRuleIndex(self):
            return cddlParser.RULE_knows_object

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKnows_object" ):
                listener.enterKnows_object(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKnows_object" ):
                listener.exitKnows_object(self)




    def knows_object(self):

        localctx = cddlParser.Knows_objectContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_knows_object)
        self._la = 0 # Token type
        try:
            self.state = 167
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 154
                self.obj()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 155
                self.obj()
                self.state = 156
                self.match(cddlParser.T__4)
                self.state = 157
                self.knows_object()
                self.state = 162
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==cddlParser.T__5:
                    self.state = 158
                    self.match(cddlParser.T__5)
                    self.state = 159
                    self.knows_object()
                    self.state = 164
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 165
                self.match(cddlParser.T__6)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Obj_createContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(cddlParser.ID, 0)

        def eq_list(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.Eq_listContext)
            else:
                return self.getTypedRuleContext(cddlParser.Eq_listContext,i)


        def getRuleIndex(self):
            return cddlParser.RULE_obj_create

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterObj_create" ):
                listener.enterObj_create(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitObj_create" ):
                listener.exitObj_create(self)




    def obj_create(self):

        localctx = cddlParser.Obj_createContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_obj_create)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            self.match(cddlParser.ID)
            self.state = 170
            self.match(cddlParser.T__4)
            self.state = 171
            self.eq_list()
            self.state = 176
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==cddlParser.T__5:
                self.state = 172
                self.match(cddlParser.T__5)
                self.state = 173
                self.eq_list()
                self.state = 178
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 179
            self.match(cddlParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Eq_listContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(cddlParser.ID, 0)

        def expr(self):
            return self.getTypedRuleContext(cddlParser.ExprContext,0)


        def getRuleIndex(self):
            return cddlParser.RULE_eq_list

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEq_list" ):
                listener.enterEq_list(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEq_list" ):
                listener.exitEq_list(self)




    def eq_list(self):

        localctx = cddlParser.Eq_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_eq_list)
        try:
            self.state = 185
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 181
                self.match(cddlParser.ID)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 182
                self.match(cddlParser.ID)
                self.state = 183
                self.match(cddlParser.T__20)
                self.state = 184
                self.expr(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ObjContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self, i:int=None):
            if i is None:
                return self.getTokens(cddlParser.ID)
            else:
                return self.getToken(cddlParser.ID, i)

        def getRuleIndex(self):
            return cddlParser.RULE_obj

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterObj" ):
                listener.enterObj(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitObj" ):
                listener.exitObj(self)




    def obj(self):

        localctx = cddlParser.ObjContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_obj)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 187
            self.match(cddlParser.ID)
            self.state = 192
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,17,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 188
                    self.match(cddlParser.T__21)
                    self.state = 189
                    self.match(cddlParser.ID) 
                self.state = 194
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,17,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return cddlParser.RULE_expr

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)


    class ExprObjContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def obj(self):
            return self.getTypedRuleContext(cddlParser.ObjContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprObj" ):
                listener.enterExprObj(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprObj" ):
                listener.exitExprObj(self)


    class ExprParenContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(cddlParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprParen" ):
                listener.enterExprParen(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprParen" ):
                listener.exitExprParen(self)


    class ExprStringContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(cddlParser.STRING, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprString" ):
                listener.enterExprString(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprString" ):
                listener.exitExprString(self)


    class ExprCompContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def comp(self):
            return self.getTypedRuleContext(cddlParser.CompContext,0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.ExprContext)
            else:
                return self.getTypedRuleContext(cddlParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprComp" ):
                listener.enterExprComp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprComp" ):
                listener.exitExprComp(self)


    class ExprExistContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(cddlParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprExist" ):
                listener.enterExprExist(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprExist" ):
                listener.exitExprExist(self)


    class ExprNotContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(cddlParser.ExprContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprNot" ):
                listener.enterExprNot(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprNot" ):
                listener.exitExprNot(self)


    class ExprBoolContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.ExprContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def bool_val(self):
            return self.getTypedRuleContext(cddlParser.Bool_valContext,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprBool" ):
                listener.enterExprBool(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprBool" ):
                listener.exitExprBool(self)


    class ExprBinCompContext(ExprContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.ExprContext
            super().__init__(parser)
            self.left = None # ExprContext
            self.right = None # ExprContext
            self.copyFrom(ctx)

        def bin_comp(self):
            return self.getTypedRuleContext(cddlParser.Bin_compContext,0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(cddlParser.ExprContext)
            else:
                return self.getTypedRuleContext(cddlParser.ExprContext,i)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprBinComp" ):
                listener.enterExprBinComp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprBinComp" ):
                listener.exitExprBinComp(self)



    def expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = cddlParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 32
        self.enterRecursionRule(localctx, 32, self.RULE_expr, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 207
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [cddlParser.T__22]:
                localctx = cddlParser.ExprParenContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 196
                self.match(cddlParser.T__22)
                self.state = 197
                self.expr(0)
                self.state = 198
                self.match(cddlParser.T__23)
                pass
            elif token in [cddlParser.T__24]:
                localctx = cddlParser.ExprNotContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 200
                self.match(cddlParser.T__24)
                self.state = 201
                self.expr(7)
                pass
            elif token in [cddlParser.T__25]:
                localctx = cddlParser.ExprExistContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 202
                self.match(cddlParser.T__25)
                self.state = 203
                self.expr(6)
                pass
            elif token in [cddlParser.T__26, cddlParser.T__27]:
                localctx = cddlParser.ExprBoolContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 204
                self.bool_val()
                pass
            elif token in [cddlParser.ID]:
                localctx = cddlParser.ExprObjContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 205
                self.obj()
                pass
            elif token in [cddlParser.STRING]:
                localctx = cddlParser.ExprStringContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 206
                self.match(cddlParser.STRING)
                pass
            else:
                raise NoViableAltException(self)

            self._ctx.stop = self._input.LT(-1)
            self.state = 219
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,20,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 217
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
                    if la_ == 1:
                        localctx = cddlParser.ExprCompContext(self, cddlParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 209
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 210
                        self.comp()
                        self.state = 211
                        localctx.right = self.expr(6)
                        pass

                    elif la_ == 2:
                        localctx = cddlParser.ExprBinCompContext(self, cddlParser.ExprContext(self, _parentctx, _parentState))
                        localctx.left = _prevctx
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 213
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 214
                        self.bin_comp()
                        self.state = 215
                        localctx.right = self.expr(5)
                        pass

             
                self.state = 221
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,20,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class Bool_valContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return cddlParser.RULE_bool_val

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBool_val" ):
                listener.enterBool_val(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBool_val" ):
                listener.exitBool_val(self)




    def bool_val(self):

        localctx = cddlParser.Bool_valContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_bool_val)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 222
            _la = self._input.LA(1)
            if not(_la==cddlParser.T__26 or _la==cddlParser.T__27):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class CompContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return cddlParser.RULE_comp

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class INContext(CompContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.CompContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIN" ):
                listener.enterIN(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIN" ):
                listener.exitIN(self)


    class NEContext(CompContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.CompContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNE" ):
                listener.enterNE(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNE" ):
                listener.exitNE(self)


    class EQContext(CompContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a cddlParser.CompContext
            super().__init__(parser)
            self.copyFrom(ctx)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEQ" ):
                listener.enterEQ(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEQ" ):
                listener.exitEQ(self)



    def comp(self):

        localctx = cddlParser.CompContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_comp)
        try:
            self.state = 227
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [cddlParser.T__28]:
                localctx = cddlParser.NEContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 224
                self.match(cddlParser.T__28)
                pass
            elif token in [cddlParser.T__18]:
                localctx = cddlParser.INContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 225
                self.match(cddlParser.T__18)
                pass
            elif token in [cddlParser.T__29]:
                localctx = cddlParser.EQContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 226
                self.match(cddlParser.T__29)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Bin_compContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return cddlParser.RULE_bin_comp

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBin_comp" ):
                listener.enterBin_comp(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBin_comp" ):
                listener.exitBin_comp(self)




    def bin_comp(self):

        localctx = cddlParser.Bin_compContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_bin_comp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 229
            _la = self._input.LA(1)
            if not(_la==cddlParser.T__30 or _la==cddlParser.T__31):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[16] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx:ExprContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 4)
         




