class StepParseError(Exception):
    pass


class RatDisconnectedError(Exception):
    pass


class InvalidTimeoutExceptionError(Exception):
    pass


class RatCallbackTimeoutError(Exception):
    pass


class MissingFileError(Exception):
    pass
