=============
Operation API
=============


.. automodule:: caldera.app.operation.operation
   :members:
